"""
backend/ai/tf_model.py

TensorFlow-backed stubs for quiz generation and answer explanation.
If TensorFlow is not available, the module falls back to simple heuristics.
This keeps the API functional while allowing you to add/replace a TF model later.
"""

import os
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

# Try to import TensorFlow. If unavailable, we'll use fallbacks.
try:
    import tensorflow as tf
    TF_AVAILABLE = True
    logger.info("TensorFlow is available for AI tasks.")
except Exception as e:
    tf = None
    TF_AVAILABLE = False
    logger.warning(f"TensorFlow not available, using fallback logic: {e}")

def load_model(model_path: str = None):
    \"\"\"Attempt to load a TensorFlow model from model_path. Returns None on failure.\"\"\"
    if not TF_AVAILABLE:
        return None
    try:
        if model_path and os.path.exists(model_path):
            model = tf.keras.models.load_model(model_path)
            logger.info(f\"Loaded TF model from {model_path}\")
            return model
        logger.info(\"No model path provided or path doesn't exist; skipping model load.\")
        return None
    except Exception as e:
        logger.exception(f\"Failed to load model: {e}\")
        return None

# Placeholder model variable (can be set by calling load_model)
MODEL = None

def generate_quiz(topic: str, difficulty: str = 'medium', num_questions: int = 5, preview: bool = False) -> Dict[str, Any]:
    \"\"\"Generate a quiz object. If a TF model is available it may be used; otherwise use a simple generator.\"\"\"
    # Simple fallback generator
    questions = []
    for i in range(num_questions):
        q = {
            "id": f"q{i+1}",
            "question": f\"{topic} question {i+1} (auto-generated at {difficulty})\",
            "options": [\"A\", \"B\", \"C\", \"D\"],
            "answer": \"A\"
        }
        questions.append(q)

    quiz = {
        "title": f\"{topic.capitalize()} Quiz ({difficulty})\",
        "description": f\"Auto-generated quiz on {topic} with {num_questions} questions.\",
        "difficulty": difficulty.capitalize(),
        "time": max(5, num_questions * 2),
        "questions": questions
    }

    # If MODEL exists, you can call it here to generate content (left as a TODO)
    if MODEL is not None and TF_AVAILABLE:
        try:
            # Example: model prediction logic (highly application-specific)
            # preds = MODEL.predict([...])
            pass
        except Exception as e:
            logger.exception(f\"Error running TF model for generation: {e}\")

    return quiz

def explain_answers(quiz: Dict[str, Any], student_answers: Dict[str, str]) -> Dict[str, Any]:
    \"\"\"Return an explanation and score for a submitted quiz.\"\"\"
    correct = 0
    mistakes = []
    for q in quiz.get('questions', []):
        qid = q.get('id') or q.get('question')
        expected = q.get('answer')
        given = student_answers.get(qid)
        if given == expected:
            correct += 1
        else:
            mistakes.append({
                "question_id": qid,
                "expected": expected,
                "given": given,
                "explanation": f\"The correct answer is {expected}. Review {quiz.get('title')} topics.\"
            })

    score = correct
    feedback = {
        "score": score,
        "total": len(quiz.get('questions', [])),
        "mistakes": mistakes,
        "summary": f\"Scored {score}/{len(quiz.get('questions', []))}\"\
    }

    # If TF model is available, you could generate richer explanations here
    return feedback
