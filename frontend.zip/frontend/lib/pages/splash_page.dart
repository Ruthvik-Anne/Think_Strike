import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../models/role.dart';

class SplashPage extends StatefulWidget { const SplashPage({super.key}); @override State<SplashPage> createState()=>_SplashPageState(); }
class _SplashPageState extends State<SplashPage> {
  @override void initState(){ super.initState(); _init(); }
  Future<void> _init() async {
    final auth = context.read<AuthState>(); await auth.load(); if (auth.token!=null){ await auth.refreshMe(); }
    if (!mounted) return;
    switch (auth.role){
      case UserRole.admin: Navigator.of(context).pushReplacementNamed('/admin'); break;
      case UserRole.teacher: Navigator.of(context).pushReplacementNamed('/teacher'); break;
      case UserRole.student: Navigator.of(context).pushReplacementNamed('/student'); break;
      default: Navigator.of(context).pushReplacementNamed('/login');
    }
  }
  @override Widget build(BuildContext context){ return const Scaffold(body: Center(child: CircularProgressIndicator())); }
}
