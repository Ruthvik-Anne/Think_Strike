import 'package:flutter/material.dart';
class BeigePalette {
  static const baseBackground = Color(0xFFF6F1E7);
  static const softBrown = Color(0xFF7B5E57);
}
